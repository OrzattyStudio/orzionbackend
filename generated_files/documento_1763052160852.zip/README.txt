Instrucciones:
1. Descomprimir el archivo
2. Abrir index.html en tu navegador

¡Gracias por elegirnos, Dylan!